# benhnhan.py
from dataclasses import dataclass


@dataclass
class BenhNhan:
    cccd: str
    hoTen: str
    ngaySinh: str
    gioiTinh: int  # 1: Nam, 0: Nu
    sdt: str
    diaChi: str


def _kiemTraCCCD(cccd: str) -> bool:
    return len(cccd) == 12 and cccd.isdigit()


def _kiemTraSDT(sdt: str) -> bool:
    return len(sdt) == 10 and sdt.isdigit()


def _kiemTraTen(ten: str) -> bool:
    ten = ten.strip()
    return 4 <= len(ten) <= 50


def _kiemTraDiaChi(dc: str) -> bool:
    dc = dc.strip()
    return 3 <= len(dc) <= 50


def _kiemTraNgaySinh(ns: str) -> bool:
    if len(ns) != 10:
        return False
    if ns[2] != "/" or ns[5] != "/":
        return False
    try:
        d, m, y = map(int, ns.split("/"))
        return 1 <= d <= 31 and 1 <= m <= 12 and 1900 <= y <= 2100
    except Exception:
        return False


def inThongTinBenhNhan(bn: BenhNhan) -> None:
    gioi_tinh_str = "Nam" if bn.gioiTinh == 1 else "Nu"
    print("\n===== Thong tin benh nhan =====")
    print(f"CCCD       : {bn.cccd}")
    print(f"Ho Ten     : {bn.hoTen}")
    print(f"Ngay Sinh  : {bn.ngaySinh}")
    print(f"Gioi Tinh  : {gioi_tinh_str}")
    print(f"SDT        : {bn.sdt}")
    print(f"Dia Chi    : {bn.diaChi}")
    print("================================")


def themBenhNhan(ht, trie, filename: str = "BENHNHAN.TXT") -> None:
    """
    ht   : đối tượng BenhNhanHash (nhưng không cần import ở đây)
    trie : đối tượng Trie (không cần import ở đây)
    """
    print("\n=== Them benh nhan moi ===")

    # CCCD
    while True:
        cccd = input("Nhap CCCD (12 so): ").strip()
        if not _kiemTraCCCD(cccd):
            print(" CCCD khong hop le, nhap lai.")
            continue
        if ht.search(cccd) is not None:
            print(" CCCD da ton tai, nhap so khac.")
            continue
        break

    # Họ tên
    while True:
        hoTen = input("Nhap ho ten (4-50 ky tu): ").strip()
        if _kiemTraTen(hoTen):
            break
        print(" Ho ten khong hop le, nhap lai.")

    # Ngày sinh
    while True:
        ngaySinh = input("Nhap ngay sinh (DD/MM/YYYY): ").strip()
        if _kiemTraNgaySinh(ngaySinh):
            break
        print(" Ngay sinh khong hop le, nhap lai.")

    # Giới tính
    while True:
        try:
            gioiTinh = int(input("Nhap gioi tinh (1: Nam, 0: Nu): ").strip())
        except ValueError:
            print(" Vui long nhap 0 hoac 1.")
            continue
        if gioiTinh in (0, 1):
            break
        print(" Gioi tinh khong hop le, nhap lai.")

    # SĐT
    while True:
        sdt = input("Nhap so dien thoai (10 so): ").strip()
        if _kiemTraSDT(sdt):
            break
        print(" So dien thoai khong hop le, nhap lai.")

    # Địa chỉ
    while True:
        diaChi = input("Nhap dia chi (3-50 ky tu): ").strip()
        if _kiemTraDiaChi(diaChi):
            break
        print(" Dia chi khong hop le, nhap lai.")

    bn = BenhNhan(cccd, hoTen, ngaySinh, gioiTinh, sdt, diaChi)

    # Ghi file
    with open(filename, "a", encoding="utf-8") as f:
        f.write(f"{bn.cccd}|{bn.hoTen}|{bn.ngaySinh}|{bn.gioiTinh}|{bn.sdt}|{bn.diaChi}\n")

    # Cập nhật hash & trie (2 đối tượng này được truyền vào từ main)
    ht.insert(bn)
    trie.insert_name(bn.hoTen, bn)

    print(" Da them benh nhan thanh cong!")


def timBenhNhan(ht, trie) -> None:
    print("\nTim kiem:")
    print("1. Theo CCCD")
    print("2. Theo Ten")
    try:
        luaChon = int(input("Nhap lua chon: ").strip())
    except ValueError:
        print(" Lua chon khong hop le.")
        return

    tuKhoa = input("Nhap tu khoa: ").strip()

    if luaChon == 1:
        bn = ht.search(tuKhoa)
        if bn:
            inThongTinBenhNhan(bn)
        else:
            print(" Khong tim thay benh nhan!")
    elif luaChon == 2:
        results = trie.search_keyword(tuKhoa)
        if not results:
            print(" Khong tim thay benh nhan co tu khoa nay.")
            return
        print(f"\nBenh nhan chua tu khoa '{tuKhoa}':")
        for bn in results:
            inThongTinBenhNhan(bn)
    else:
        print(" Lua chon khong hop le.")
