# trie_ds.py
from collections import defaultdict


class TrieNode:
    def __init__(self):
        self.children: dict[str, "TrieNode"] = {}
        self.records: list[object] = []  # lưu BenhNhan hoặc LichSuKham


class Trie:
    def __init__(self):
        self.root = TrieNode()

    def _insert_word(self, word: str, record: object) -> None:
        p = self.root
        for ch in word.lower():
            if ch not in p.children:
                p.children[ch] = TrieNode()
            p = p.children[ch]
        p.records.append(record)

    def insert_name(self, name: str, record: object) -> None:
        # giống chenBenhNhanVaoTrie: tách theo dấu cách :contentReference[oaicite:6]{index=6}
        for token in name.strip().split():
            if token:
                self._insert_word(token, record)

    def search_keyword(self, keyword: str) -> list[object]:
        p = self.root
        for ch in keyword.lower():
            if ch not in p.children:
                return []
            p = p.children[ch]
        # có thể loại trùng (record xuất hiện nhiều lần nếu nhiều từ trùng)
        seen = set()
        results = []
        for rec in p.records:
            if id(rec) not in seen:
                seen.add(id(rec))
                results.append(rec)
        return results
