# main.py
from benhnhan_hash import BenhNhanHash
from trie_ds import Trie
from benhnhan import themBenhNhan, timBenhNhan
from kham import KhamManager
from lichsu2 import LichSuManager
from menu import MenuItem, inMenu, xuLyLuaChon


def menuTimLichSuToiUu(lichsu_mgr: LichSuManager) -> None:
    print("\nTim kiem lich su kham (Toi uu):")
    print("1. Theo CCCD")
    print("2. Theo Ten")
    print("3. Theo Muc do")
    try:
        luaChon = int(input("Chon: ").strip())
    except ValueError:
        print(" Lua chon khong hop le.")
        return

    if luaChon == 1:
        cccd = input("Nhap CCCD: ").strip()
        lichsu_mgr.timTheoCCCD(cccd)
    elif luaChon == 2:
        tuKhoa = input("Nhap tu khoa ten: ").strip()
        lichsu_mgr.timTheoTen(tuKhoa)
    elif luaChon == 3:
        try:
            mucDo = int(input("Nhap muc do (1-3): ").strip())
        except ValueError:
            print(" Muc do khong hop le.")
            return
        lichsu_mgr.timTheoMucDo(mucDo)
    else:
        print(" Lua chon khong hop le.")


def main():
    print("Bat dau chuong trinh...")

    # Load du lieu benh nhan (HashTable) :contentReference[oaicite:11]{index=11}
    ht = BenhNhanHash.load_from_file("BENHNHAN.TXT")
    if not ht.table:
        print("Khong the tai (hoac khong co) du lieu benh nhan.")
    else:
        print("Tai du lieu benh nhan thanh cong.")

    # Khoi tao trie & nap benh nhan vao trie
    trie_bn = Trie()
    for bn in ht.values():
        trie_bn.insert_name(bn.hoTen, bn)

    # Khoi tao & load lich su toi uu
    lichsu_mgr = LichSuManager()
    lichsu_mgr.load_from_file("LICHSUKHAMBENH.TXT")

    # Manager kham benh (heap)
    kham_mgr = KhamManager(ht, lichsu_mgr, history_file="LICHSUKHAMBENH.TXT")

    # Cần bọc các hàm để phù hợp chữ ký action() không tham số
    def action_themBenhNhan():
        themBenhNhan(ht, trie_bn, "BENHNHAN.TXT")

    def action_themKhamBenh():
        kham_mgr.themKhamBenh()

    def action_goiKhamBenh():
        kham_mgr.goiKhamBenh()

    def action_timBenhNhan():
        timBenhNhan(ht, trie_bn)

    def action_timLichSuThuong():
        from lichsu2 import LichSuManager
        LichSuManager.timLichSuKham_thuong("LICHSUKHAMBENH.TXT")

    def action_timLichSuToiUu():
        menuTimLichSuToiUu(lichsu_mgr)

    menu = [
        MenuItem(1, "Them benh nhan moi", action_themBenhNhan),
        MenuItem(2, "Them danh sach kham benh", action_themKhamBenh),
        MenuItem(3, "Goi kham benh", action_goiKhamBenh),
        MenuItem(4, "Tim thong tin benh nhan", action_timBenhNhan),
        MenuItem(5, "Tim lich su kham benh (thuong)", action_timLichSuThuong),
        MenuItem(6, "Tim lich su kham benh (Toi uu)", action_timLichSuToiUu),
        MenuItem(0, "Thoat", None),
    ]

    while True:
        inMenu(menu)
        try:
            choice = int(input("Nhap lua chon: ").strip())
        except ValueError:
            print("Nhap sai! Vui long nhap mot so.")
            continue

        if choice == 0:
            xuLyLuaChon(menu, 0)
            break

        xuLyLuaChon(menu, choice)

    print("Ket thuc chuong trinh.")


if __name__ == "__main__":
    main()
