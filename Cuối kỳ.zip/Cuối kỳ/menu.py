# menu.py
from dataclasses import dataclass
from typing import Callable, Optional


@dataclass
class MenuItem:
    id: int
    text: str
    action: Optional[Callable[[], None]]


def inMenu(menu: list[MenuItem]) -> None:
    print("\n===== MENU =====")
    for item in menu:
        print(f"{item.id}. {item.text}")


def xuLyLuaChon(menu: list[MenuItem], id: int) -> None:
    for item in menu:
        if item.id == id:
            if item.action is not None:
                item.action()
            else:
                print("Thoat chuong trinh...")
            return
    print(" Lua chon khong hop le.")
