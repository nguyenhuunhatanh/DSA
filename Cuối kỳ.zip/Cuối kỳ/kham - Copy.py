# kham.py
from dataclasses import dataclass
import heapq
from datetime import datetime

from benhnhan import BenhNhan, inThongTinBenhNhan
from lichsu2 import LichSuKham


@dataclass
class PhieuKham:
    bn: BenhNhan
    mucUuTien: int          # 1: cap cuu, 2: uu tien, 3: thuong
    moTa: str               # mo ta/loai benh luc dang ky (<=50)
    sttKham: int            # STT (chi dung cho muc 3)
    arrival: int            # thu tu den (pha hoa FIFO cho muc 1/2)
    thoiGianDangKy: str     # "DD/MM/YYYY HH:MM:SS"


class KhamManager:
    def __init__(self, ht, lichsu_manager, history_file: str = "LICHSUKHAMBENH.TXT"):
        self.heap: list[tuple[tuple[int, int, int, int], PhieuKham]] = []

        self.arrival_counter = 0
        self.stt_thuong_counter = 0
        self.so_thu_tu_duoc_kham = 0

        self.ht = ht
        self.lichsu = lichsu_manager
        self.history_file = history_file

    def _make_key(self, pk: PhieuKham) -> tuple[int, int, int, int]:
        prio_rank = {1: 0, 2: 1, 3: 2}.get(pk.mucUuTien, 2)

        if pk.mucUuTien in (1, 2):
            group = 0
            third = pk.arrival
        else:
            group = 1
            third = pk.sttKham

        return (prio_rank, group, third, pk.arrival)

    def _tg_hms(self, tg: str) -> str:
        if tg and len(tg) >= 8:
            return tg[-8:]
        return ""

    @staticmethod
    def _safe_text(s: str) -> str:
        # tránh phá format cccd|hoTen|...|moTa
        return (s or "").replace("|", "/")

    def _compose_history_note(self, pk: PhieuKham, ketqua: str) -> str:
        """
        Giữ đúng format file lịch sử 6 trường:
        cccd|hoTen|ngaySinh|mucUuTien|ngayKham|moTa

        => tuyệt đối KHÔNG dùng ký tự '|' trong moTa
        """
        parts = []
        if pk.mucUuTien == 1:
            parts.append(f"TGDK:{pk.thoiGianDangKy}")
        if pk.moTa:
            parts.append(pk.moTa)
        if ketqua:
            parts.append(ketqua)

        # Dùng '; ' thay vì ' | ' để không tạo thêm cột khi split("|")
        return "; ".join(parts)[:50]

    def themKhamBenh(self) -> None:
        cccd = input("Nhap CCCD benh nhan: ").strip()
        node = self.ht.search(cccd)
        if not node:
            print(" Khong tim thay benh nhan!")
            return

        inThongTinBenhNhan(node)

        while True:
            try:
                muc = int(input("Nhap muc do uu tien (1: cap cuu, 2: uu tien, 3: thuong): ").strip())
            except ValueError:
                print(" Muc do khong hop le.")
                continue
            if muc not in (1, 2, 3):
                print(" Muc do khong hop le.")
                continue
            break

        moTa = self._safe_text(input("Nhap mo ta/loai benh (<50 ky tu): ").strip())[:50]

        tgdk = datetime.now().strftime("%d/%m/%Y %H:%M:%S")

        self.arrival_counter += 1
        arrival = self.arrival_counter

        if muc == 3:
            self.stt_thuong_counter += 1
            stt = self.stt_thuong_counter
        else:
            stt = 0

        pk = PhieuKham(node, muc, moTa, stt, arrival, tgdk)
        heapq.heappush(self.heap, (self._make_key(pk), pk))

        print(" Da them vao danh sach cho kham.")
        if muc == 1:
            print(f" (CAP CUU) Thoi gian dang ky: {tgdk}")

    def goiKhamBenh(self) -> None:
        if not self.heap:
            print(" Khong co benh nhan trong danh sach cho!")
            return

        waiting = sorted(self.heap, key=lambda x: x[0])

        print("\nDanh sach cho kham:")
        for idx, (key, pk) in enumerate(waiting, start=1):
            tg_show = self._tg_hms(pk.thoiGianDangKy)
            tg_prefix = f"[{tg_show}] " if tg_show else ""

            if pk.mucUuTien == 3:
                print(f"#{idx} {tg_prefix}(THUONG - STT {pk.sttKham}) - {pk.bn.hoTen} - {pk.bn.ngaySinh}")
            else:
                print(f"#{idx} {tg_prefix}(UU TIEN {pk.mucUuTien}) - {pk.bn.hoTen} - {pk.bn.ngaySinh}")

        input("\nNhan Enter de goi benh nhan dau tien... ")

        _, goi = heapq.heappop(self.heap)
        self.so_thu_tu_duoc_kham += 1

        print(f"\n>>> Dang goi benh nhan #{self.so_thu_tu_duoc_kham}:")
        inThongTinBenhNhan(goi.bn)

        if goi.mucUuTien == 1:
            print(f"*** CAP CUU - Thoi gian dang ky: {goi.thoiGianDangKy} ***")

        input("\nKhi benh nhan kham xong an Enter... ")

        ngayKham = input("Nhap ngay kham (DD/MM/YYYY): ").strip()
        moTaKham = self._safe_text(input("Nhap ket qua kham benh (<50): ").strip())[:50]

        moTaGhi = self._compose_history_note(goi, moTaKham)

        with open(self.history_file, "a", encoding="utf-8") as fp:
            fp.write(
                f"{goi.bn.cccd}|{goi.bn.hoTen}|{goi.bn.ngaySinh}|"
                f"{goi.mucUuTien}|{ngayKham}|{moTaGhi}\n"
            )

        ls = LichSuKham(
            cccd=goi.bn.cccd,
            hoTen=goi.bn.hoTen,
            ngaySinh=goi.bn.ngaySinh,
            mucDo=goi.mucUuTien,
            ngayKham=ngayKham,
            moTa=moTaGhi,
        )
        self.lichsu.add_record(ls)

        print(" Da luu vao lich su kham benh.")
