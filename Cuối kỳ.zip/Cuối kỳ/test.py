import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch

# ---------- Helpers ----------
def add_box(ax, cx, cy, w, h, text, fontsize=10, lw=1.5):
    """Draw a rounded box centered at (cx, cy)."""
    x = cx - w / 2
    y = cy - h / 2
    box = FancyBboxPatch(
        (x, y), w, h,
        boxstyle="round,pad=0.01,rounding_size=0.02",
        linewidth=lw, edgecolor="black", facecolor="white"
    )
    ax.add_patch(box)
    ax.text(cx, cy, text, ha="center", va="center", fontsize=fontsize)
    return (x, y, w, h)

def arrow(ax, x1, y1, x2, y2, lw=1.5, head=10):
    """Arrow from (x1,y1) to (x2,y2)."""
    a = FancyArrowPatch(
        (x1, y1), (x2, y2),
        arrowstyle='-|>',
        mutation_scale=head,
        linewidth=lw,
        color="black",
        shrinkA=0, shrinkB=0
    )
    ax.add_patch(a)

def line(ax, x1, y1, x2, y2, lw=1.5):
    ax.plot([x1, x2], [y1, y2], color="black", linewidth=lw)


# ---------- Figure ----------
plt.rcParams["font.family"] = "DejaVu Sans"  # hỗ trợ tiếng Việt khá ổn

fig, ax = plt.subplots(figsize=(12, 6), dpi=160)
ax.set_xlim(0, 1)
ax.set_ylim(0, 1)
ax.set_aspect("equal")
ax.axis("off")

lw = 1.6

# ---------- Top box ----------
top = add_box(ax, 0.5, 0.88, 0.18, 0.09, "Hệ thống quản lí\nkhám bệnh", fontsize=11, lw=lw)

# ---------- Horizontal bar ----------
bar_y = 0.74
bar_left, bar_right = 0.12, 0.88
# vertical line from top to bar center
top_bottom_y = top[1]  # y of bottom-left of top box
top_center_x = 0.5
line(ax, top_center_x, top_bottom_y, top_center_x, bar_y, lw=lw)
# horizontal bar
line(ax, bar_left, bar_y, bar_right, bar_y, lw=lw)

# ---------- 3 main boxes ----------
m_y = 0.60
m_w, m_h = 0.22, 0.09

m1 = add_box(ax, 0.20, m_y, m_w, m_h, "Quản lí thông tin\nbệnh nhân", fontsize=10.5, lw=lw)
m2 = add_box(ax, 0.50, m_y, m_w, m_h, "Quản lí lịch sử khám\nbệnh", fontsize=10.5, lw=lw)
m3 = add_box(ax, 0.80, m_y, m_w, m_h, "Quản lí hàng chờ\n(có ưu tiên)", fontsize=10.5, lw=lw)

# arrows from bar down to each main box (đúng kiểu mũi tên đi xuống)
def down_to_box(cx, box, from_y=bar_y):
    box_top_y = box[1] + box[3]  # y + h
    arrow(ax, cx, from_y, cx, box_top_y, lw=lw, head=12)

down_to_box(0.20, m1)
down_to_box(0.50, m2)
down_to_box(0.80, m3)

# ---------- Trunks + sub boxes (RIGHT of trunk) ----------
s_w, s_h = 0.18, 0.075

def branch(ax, main_box, trunk_x, sub_centers, sub_texts, sub_x, extra_down=0.02):
    """
    main_box: (x,y,w,h)
    trunk_x : x coordinate for vertical trunk
    sub_centers: list of y centers for sub boxes
    sub_x : x center for sub boxes
    """
    main_bottom_y = main_box[1]  # y of main bottom
    trunk_top_y = main_bottom_y
    trunk_bottom_y = min(sub_centers) - s_h/2 - extra_down

    # vertical trunk
    line(ax, trunk_x, trunk_top_y, trunk_x, trunk_bottom_y, lw=lw)

    # sub boxes + arrows from trunk to each sub box
    for y, txt in zip(sub_centers, sub_texts):
        sb = add_box(ax, sub_x, y, s_w, s_h, txt, fontsize=10.5, lw=lw)
        sub_left_x = sb[0]
        arrow(ax, trunk_x, y, sub_left_x, y, lw=lw, head=12)

# Left branch (2 subs)
branch(
    ax, m1, trunk_x=0.20,
    sub_centers=[0.43, 0.29],
    sub_texts=["Lưu trữ", "Tìm kiếm"],
    sub_x=0.36,
    extra_down=0.03
)

# Middle branch (2 subs)
branch(
    ax, m2, trunk_x=0.50,
    sub_centers=[0.43, 0.29],
    sub_texts=["Lưu trữ", "Tìm kiếm"],
    sub_x=0.66,
    extra_down=0.03
)

# Right branch (3 subs) – sub boxes rộng hơn chút để giống ảnh
s_w_r = 0.20
def branch_right(ax, main_box):
    trunk_x = 0.80
    ys = [0.43, 0.30, 0.17]
    texts = ["Hiển thị", "Thêm vào hàng chờ", "Xóa khỏi hàng chờ"]
    main_bottom_y = main_box[1]
    trunk_bottom_y = min(ys) - s_h/2 - 0.03
    line(ax, trunk_x, main_bottom_y, trunk_x, trunk_bottom_y, lw=lw)

    for y, txt in zip(ys, texts):
        sb = add_box(ax, 0.92, y, s_w_r, s_h, txt, fontsize=10.3, lw=lw)
        arrow(ax, trunk_x, y, sb[0], y, lw=lw, head=12)

branch_right(ax, m3)

# Save
plt.tight_layout()
plt.savefig("so_do_chuc_nang.png", bbox_inches="tight")
plt.show()
