from benhnhan import BenhNhan


class BenhNhanHash:
    """
    Bảng băm quản lý bệnh nhân theo CCCD.
    Thay thế cho HashTable trong C.
    """

    def __init__(self):
        # key: cccd (str) -> value: BenhNhan
        self.table: dict[str, BenhNhan] = {}

    def insert(self, bn: BenhNhan) -> None:
        """Thêm 1 bệnh nhân vào hash."""
        self.table[bn.cccd] = bn

    def search(self, cccd: str) -> BenhNhan | None:
        """Tìm bệnh nhân theo CCCD. Không thấy thì trả về None."""
        return self.table.get(cccd)

    def values(self):
        """Trả về iterator tất cả bệnh nhân (dùng để nạp vào Trie)."""
        return self.table.values()

    @staticmethod
    def load_from_file(filename: str) -> "BenhNhanHash":
        """Đọc BENHNHAN.TXT và đưa vào hash."""
        ht = BenhNhanHash()
        try:
            with open(filename, "r", encoding="utf-8") as f:
                for line in f:
                    line = line.strip()
                    if not line:
                        continue
                    parts = line.split("|")
                    if len(parts) != 6:
                        continue

                    cccd, hoTen, ngaySinh, gioiTinh_str, sdt, diaChi = parts
                    try:
                        gioiTinh = int(gioiTinh_str)
                    except ValueError:
                        gioiTinh = 1  # mặc định Nam

                    bn = BenhNhan(cccd, hoTen, ngaySinh, gioiTinh, sdt, diaChi)
                    ht.insert(bn)
        except FileNotFoundError:
            # Không có file vẫn OK, trả về hash rỗng
            pass

        return ht
