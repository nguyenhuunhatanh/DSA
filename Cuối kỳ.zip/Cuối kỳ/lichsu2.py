# lichsu2.py
from dataclasses import dataclass
from trie_ds import Trie


@dataclass
class LichSuKham:
    cccd: str
    hoTen: str
    ngaySinh: str
    mucDo: int  # 1,2,3
    ngayKham: str
    moTa: str


class LichSuManager:
    """
    - Hash theo CCCD
    - Trie theo tên
    - Array of lists theo mucDo
    """

    def __init__(self):
        self.by_cccd: dict[str, list[LichSuKham]] = {}
        self.trie = Trie()
        self.by_mucdo: list[list[LichSuKham]] = [[], [], []]  # index 0->muc1, 1->muc2, 2->muc3

    def add_record(self, ls: LichSuKham) -> None:
        self.by_cccd.setdefault(ls.cccd, []).append(ls)
        self.trie.insert_name(ls.hoTen, ls)
        if 1 <= ls.mucDo <= 3:
            self.by_mucdo[ls.mucDo - 1].append(ls)

    def load_from_file(self, filename: str) -> None:
        """
        Đọc file lịch sử theo format 6 trường:
        cccd|hoTen|ngaySinh|mucDo|ngayKham|moTa

        SỬA: dùng split("|", 5) để tránh lỗi nếu moTa có chứa ký tự '|'
        """
        try:
            with open(filename, "r", encoding="utf-8") as f:
                for line in f:
                    line = line.strip()
                    if not line:
                        continue

                    parts = line.split("|", 5)  # <= CHỐT: chỉ tách tối đa 6 trường
                    if len(parts) < 6:
                        continue

                    cccd, hoTen, ngaySinh, mucDo_str, ngayKham, moTa = parts
                    try:
                        mucDo = int(mucDo_str)
                    except ValueError:
                        mucDo = 3

                    ls = LichSuKham(cccd, hoTen, ngaySinh, mucDo, ngayKham, moTa)
                    self.add_record(ls)
        except FileNotFoundError:
            # Không có lịch sử => để trống
            pass

    def timTheoCCCD(self, cccd: str) -> None:
        ds = self.by_cccd.get(cccd)
        if not ds:
            print(" Khong co lich su voi CCCD nay.")
            return
        for ls in ds:
            self._in_lich_su(ls)

    def timTheoTen(self, tuKhoa: str) -> None:
        results = self.trie.search_keyword(tuKhoa)
        if not results:
            print(" Khong co lich su voi tu khoa ten nay.")
            return
        for ls in results:
            self._in_lich_su(ls)

    def timTheoMucDo(self, mucDo: int) -> None:
        if not (1 <= mucDo <= 3):
            print(" Muc do khong phu hop (1-3).")
            return
        ds = self.by_mucdo[mucDo - 1]
        if not ds:
            print(" Khong co lich su voi muc do nay.")
            return
        for ls in ds:
            self._in_lich_su(ls)

    @staticmethod
    def _in_lich_su(ls: LichSuKham) -> None:
        print("\n-- Lich su kham --")
        print(f"CCCD     : {ls.cccd}")
        print(f"Ten      : {ls.hoTen}")
        print(f"Ngay sinh: {ls.ngaySinh}")
        print(f"Muc do   : {ls.mucDo}")
        print(f"Ngay kham: {ls.ngayKham}")
        print(f"Mo ta    : {ls.moTa}")

    # Bản "thường" – đọc file mỗi lần
    @staticmethod
    def timLichSuKham_thuong(filename: str = "LICHSUKHAMBENH.TXT") -> None:
        try:
            fp = open(filename, "r", encoding="utf-8")
        except FileNotFoundError:
            print(f"Khong the mo file {filename}")
            return

        print("\nTim lich su (thuong):")
        print("1. Theo CCCD")
        print("2. Theo Ten")
        print("3. Theo Muc do")
        try:
            luaChon = int(input("Nhap lua chon: ").strip())
        except ValueError:
            print(" Lua chon khong hop le.")
            fp.close()
            return

        tuKhoa = ""
        mucDoTim = 0
        if luaChon == 3:
            try:
                mucDoTim = int(input("Nhap muc do (1/2/3): ").strip())
            except ValueError:
                print(" Muc do khong hop le.")
                fp.close()
                return
        else:
            tuKhoa = input("Nhap tu khoa: ").strip()

        timThay = False
        for line in fp:
            line = line.strip()
            if not line:
                continue

            # <= CHỐT: chỉ tách tối đa 6 trường, phần dư dồn vào moTa
            parts = line.split("|", 5)
            if len(parts) < 6:
                continue

            cccd, hoTen, ngaySinh, mucDo_str, ngayKham, moTa = parts
            try:
                mucDo = int(mucDo_str)
            except ValueError:
                mucDo = 3

            match = False
            if luaChon == 1 and cccd == tuKhoa:
                match = True
            elif luaChon == 2 and tuKhoa in hoTen:
                match = True
            elif luaChon == 3 and mucDo == mucDoTim:
                match = True

            if match:
                timThay = True
                print("\n-- Lich su kham --")
                print(f"CCCD     : {cccd}")
                print(f"Ten      : {hoTen}")
                print(f"Ngay sinh: {ngaySinh}")
                print(f"Muc do   : {mucDo}")
                print(f"Ngay kham: {ngayKham}")
                print(f"Mo ta    : {moTa}")

        if not timThay:
            print("Khong tim thay lich su kham phu hop.")

        fp.close()
